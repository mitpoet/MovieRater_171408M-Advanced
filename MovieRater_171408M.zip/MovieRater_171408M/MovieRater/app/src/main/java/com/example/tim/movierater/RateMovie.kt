package com.example.tim.movierater

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class RateMovie : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rate_movie)
    }
}
