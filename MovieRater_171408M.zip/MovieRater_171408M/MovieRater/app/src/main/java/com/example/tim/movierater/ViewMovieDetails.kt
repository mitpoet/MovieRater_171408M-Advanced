package com.example.tim.movierater

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class ViewMovieDetails : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_movie_details)
    }
}
